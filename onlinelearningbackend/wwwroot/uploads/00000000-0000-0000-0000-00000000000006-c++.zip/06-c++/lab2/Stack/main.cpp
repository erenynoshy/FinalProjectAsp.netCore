#include <iostream>

using namespace std;
class Stack
{
    int * stk;
    int tos,stkSize;
public:
    Stack (int l)
    {
        stkSize=l;
        tos=0;
        stk=new int[stkSize];
    }
    ~Stack ()
    {
        delete[] stk;
        cout<<"dest";
    }
    int isFull()
    {
        return(tos==stkSize);
    }

        int isEmpty()
    {
        return(tos==0);
    }
    int pop()
    {
        if(!isEmpty())
            return stk[--tos];
        else
            cout<<"empty"<<endl;

    }
    void push(int n)
    {

    if(!isFull())
     stk[tos++]=n;
    else
        cout<<"stack is full"<<endl;
    }
    int peak()
    {
         if(!isEmpty())
            return stk[tos-1];
    }
};

int main()
{
    Stack s(4);
    s.push(5);
    s.push(7);
    cout<<s.peak()<<endl;
    cout<<s.peak()<<endl;
    cout<<s.pop()<<endl;

    return 0;
}
