#include <iostream>

using namespace std;
class Queue
{
    int * que;
    int head , tail,sizeQ;
public:
    Queue (int n)
    {
        sizeQ=n;
        head=tail=0;
        que=new int[sizeQ];
    }
    int isFull()
    {
        return(tail==sizeQ);
    }
    int isEmpty()
    {
        return(tail==head);
    }
    void enQ(int x)
    {
        if(!isFull())
        {
            que[tail++]=x;
        }
        else
            cout<<"is full"<<endl;
    }
    int deQ()
    {
        if(!isEmpty())
        {


            int x;
            x=  que[head];
            for(int i=head; i<tail; i++)
            {
                que[i]=que[i+1];
            }
            tail--;
            return x;
        }

        cout<<"is empty"<<endl;
        return -1;
    }
    int peak()
    {
        if(!isEmpty())
            return que[head];
        else
            cout<<"is empty"<<endl;
    }

};
int main()
{
    Queue q(4);
    q.enQ(5);
    q.enQ(6);
    q.enQ(7);
    q.enQ(8);
    q.enQ(8);

    cout<<q.deQ()<<endl;
    cout<<q.peak()<<endl;
    cout<<q.deQ()<<endl;


    return 0;
}
