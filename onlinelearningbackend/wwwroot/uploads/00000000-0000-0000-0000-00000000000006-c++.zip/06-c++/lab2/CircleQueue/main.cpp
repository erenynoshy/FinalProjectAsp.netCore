#include <iostream>

using namespace std;
class Queue
{
    int * que;
    int head , tail,sizeQ , countQ;
public:
    Queue (int n)
    {
        sizeQ=n;
        head=tail=0;
        que=new int[sizeQ];
        countQ=0;
    }
    int isFull()
    {
        return(countQ==sizeQ);
    }
    int isEmpty()
    {
        return(countQ==0);
    }
    void enQ(int x)
    {
        if(!isFull())
        {

            que[tail++]=x;
            if(tail==sizeQ)
                tail=0;
                countQ++;
        }
        else
            cout<<"is full"<<endl;
    }
    int deQ()
    {
        if(!isEmpty())
        {
            int x;
            x=  que[head++];
           if(head==sizeQ)
            head=0;

           countQ--;
            return x;
        }

        cout<<"is empty"<<endl;
        return -1;
    }
    int peak()
    {
        if(!isEmpty())
            return que[head];
        else
            cout<<"is empty"<<endl;
    }

};
int main()
{
    Queue q(4);
    q.enQ(5);
    q.enQ(6);
    q.enQ(7);
    q.enQ(8);
    q.enQ(8);
    cout<<q.deQ()<<endl;
    cout<<q.peak()<<endl;
    cout<<q.deQ()<<endl;


    return 0;
}
