#include <iostream>

using namespace std;
void swapFn( int & x ,int & y)
{
    int temp;

    temp=x;
    x=y;
    y=temp;
}
int main()
{
    int a=10,b=5;
    swapFn(a,b);
    cout<<"A = "<<a<<endl;
    cout<<"B = "<<b<<endl;

    return 0;
}
