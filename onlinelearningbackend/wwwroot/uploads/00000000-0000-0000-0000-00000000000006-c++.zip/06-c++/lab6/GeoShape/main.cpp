#include <iostream>
#include "graphics.h"
using namespace std;
class GeoColor
{


public:
      int color;

  GeoColor(int c){color=c;}
  GeoColor(){color=4;}

  virtual void draw ()=0;
};

class Point
{
    int x,y;
    public:

    Point()
    {
     x=y=0;
    }
      Point(int a, int b)
    {
     x=a;
     y=b;
    }
    int getX(){return x;}
    int getY(){return y;}
    void setX(int a){x=a;}
    void setY(int a){y=a;}

};
class Rect :public GeoColor
{

    Point UL,LR ;
public:
    Rect():UL(),LR(){

    }
    Rect(int x1 ,int y1 ,int x2,int y2):UL(x1,y1),LR(x2,y2)
    {

    }
    void draw ()
    {
        setcolor(color);
        rectangle(UL.getX(),UL.getY(),LR.getX(),LR.getY());
    }

};
class circ :public GeoColor
{
    int radius;
    Point p;
public:
    circ ():p()
    {
        radius=0;
    }
       circ (int x1,int y1 ,int rad):p(x1,y1)
    {
        radius=rad;
    }
     void draw ()
    {
        setcolor(color);
        circle(p.getX(),p.getY(),radius);
    }

};
class Line :public GeoColor {
    Point UL,LR ;
public:
    Line():UL(),LR(){

    }
    Line(int x1 ,int y1 ,int x2,int y2):UL(x1,y1),LR(x2,y2)
    {

    }
    void draw ()
    {
        setcolor(color);
        line(UL.getX(),UL.getY(),LR.getX(),LR.getY());
    }

};
class Pic
{
    public:
    GeoColor ** geo;
    int n;
    Pic(  GeoColor ** c ,int _n)
    {

        geo=c;
        n=_n;


    }
    void paint()
    {
        for(int i=0;i<n;i++)
            geo[i]->draw();


    }
};
int main()
{
    initgraph();
    circ *c;
    c=new circ[2];
    c[0]=circ(100,200,50);
    c[1]=circ(100,300,100);

   Rect *r=new Rect(30,380,180,450);


    Line *l;
    l=new Line[7];
    l[0]=Line(80,210,55,280);
    l[1]=Line(120,210,145,280);
    l[2]=Line(70,380,70,340);
    l[3]=Line(130,380,130,340);
    l[4]=Line(160,390,150,420);
    l[5]=Line(150,420,170,420);
    l[6]=Line(170,420,160,390);
    GeoColor *g[10]={c,&c[1],r,l,&l[1],&l[2],&l[3],&l[4],&l[5],&l[6]};
  Pic pp(g,10);
  pp.paint();



    return 0;
}
