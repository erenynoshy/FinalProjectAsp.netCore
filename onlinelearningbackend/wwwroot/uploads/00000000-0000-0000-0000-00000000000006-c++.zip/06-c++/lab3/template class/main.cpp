#include <iostream>

using namespace std;
template <class T>
class Stack
{
    T * stk;
    int tos,stkSize;
public:
    Stack (int l)
    {
        stkSize=l;
        tos=0;
        stk=new T[stkSize];
    }
    ~Stack ()
    {
        delete[] stk;
        cout<<"dest";
    }
    int isFull()
    {
        return(tos==stkSize);
    }

        int isEmpty()
    {
        return(tos==0);
    }
    T pop();

    void push(T n);

    T peak();

};
template<class T>

T Stack<T>::pop()
    {
        if(!isEmpty())
            return stk[--tos];
        else
            cout<<"empty"<<endl;

    }
    template<class T>
void Stack<T>::push(T n)
    {

    if(!isFull())
     stk[tos++]=n;
    else
        cout<<"stack is full"<<endl;
    }
     template<class T>

T Stack<T>::peak()
    {
         if(!isEmpty())
            return stk[tos-1];
    }
int main()
{
    Stack<int> s(4);
    s.push(5);
    s.push(7);
    cout<<s.peak()<<endl;
    cout<<s.peak()<<endl;
    cout<<s.pop()<<endl;

    return 0;
}
