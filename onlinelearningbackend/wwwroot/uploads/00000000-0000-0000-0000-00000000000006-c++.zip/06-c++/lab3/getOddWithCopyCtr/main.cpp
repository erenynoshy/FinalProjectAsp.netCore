#include <iostream>

using namespace std;
class Stack
{
    int * stk;
    int tos,stkSize;
public:
    Stack (int l)
    {
        stkSize=l;
        tos=0;
        stk=new int[stkSize];
    }
     Stack(const Stack & olds)
    {
        tos=olds.tos;
        stkSize=olds.stkSize;
        stk=new int[stkSize];

        for(int i=0;i<tos;i++)
            stk[i]=olds.stk[i];

    }
    ~Stack ()
    {
        for(int i=0;i<tos;i++)
            stk[i]=-1;
        delete[] stk;
        cout<<"dest"<<endl;
        stk=NULL;

    }
    int isFull()
    {
        return(tos==stkSize);
    }

        int isEmpty()
    {
        return(tos==0);
    }
    int pop()
    {
        if(!isEmpty())
            return stk[--tos];
        else
            cout<<"empty"<<endl;

    }
    void push(int n)
    {

    if(!isFull())
     stk[tos++]=n;
    else
        cout<<"stack is full"<<endl;
    }
    int peak()
    {
         if(!isEmpty())
            return stk[tos-1];
    }
    friend void viewContent(Stack s);
};
void viewContent(Stack s)
{
    for(int i=0;i<s.tos;i++)
        cout<<s.stk[i]<<endl;
}
Stack getOddStack(int l)
{
    Stack Mys(l);
    for(int i=0;i<l;i++)
        Mys.push(i*2+1);
        return Mys;
}
int main()
{
    cout<<getOddStack(5).pop();

    return 0;
}
