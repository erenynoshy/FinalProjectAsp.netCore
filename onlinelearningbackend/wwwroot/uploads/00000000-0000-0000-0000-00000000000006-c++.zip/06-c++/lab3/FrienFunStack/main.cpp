#include <iostream>

using namespace std;
class Stack
{
    int * stk;
    int tos,stkSize;
public:
    Stack (int l)
    {
        stkSize=l;
        tos=0;
        stk=new int[stkSize];
    }
    ~Stack ()
    {
        for(int i=0;i<tos;i++)
            stk[i]=-1;
        delete[] stk;
        cout<<"dest"<<endl;

    }
    int isFull()
    {
        return(tos==stkSize);
    }

        int isEmpty()
    {
        return(tos==0);
    }
    int pop()
    {
        if(!isEmpty())
            return stk[--tos];
        else
            cout<<"empty"<<endl;

    }
    void push(int n)
    {

    if(!isFull())
     stk[tos++]=n;
    else
        cout<<"stack is full"<<endl;
    }
    int peak()
    {
         if(!isEmpty())
            return stk[tos-1];
    }
    friend void viewContent(Stack s);
};
void viewContent(Stack s)
{
    for(int i=0;i<s.tos;i++)
        cout<<s.stk[i]<<endl;
}
int main()
{
    Stack s1(7);
    s1.push(3);
    s1.push(5);
    s1.push(7);
    viewContent(s1);
  cout<<s1.pop();

    return 0;
}
