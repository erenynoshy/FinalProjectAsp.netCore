#include <iostream>

using namespace std;
class cmplx
{
    int real;
    int img;
    static int numC;
     static int destC;
public :

    cmplx()
    {
        real=img=0;
        numC++;
         cout<<"const call"<<endl;;
    }
     ~cmplx()
    {
        destC++;
        cout<<"dest call"<<endl;
    }
     cmplx(const cmplx & olds)
    {
        real=olds.real;
        img=olds.img;

        numC++;
    }
       cmplx(int r , int i)
    {
        real=r;
        img=i;
    }
    cmplx operator +(const cmplx & right )
    {
        cmplx result(real+right.real,img+right.img);
        return result;
    }
     cmplx operator -(const cmplx & right )
    {
        cmplx result(real-right.real,img-right.img);
        return result;
    }
     cmplx operator +(int r )
    {
        cmplx result(real+r,img);
        return result;
    }
      cmplx operator -(int r )
    {
        cmplx result(real-r,img);
        return result;
    }

    static int getNumC()
    {
        return numC;
    }
    static int getDestC()
    {
        return destC;
    }
    void setReal(int R)
    {
        real=R;
    }
     int getReal()
    {
        return real;
    }
     void setImg(int i)
    {
        img=i;
    }
     int getImg()
    {
        return img;
    }
    void print()
    {
        if( real>0&& img >0 )
          cout<<real<<"+"<<img<<"i";
          else if(real ==0&&img ==0)
            cout<<real;
          else if(real==0&&img!=0)
            cout<<img<<"i";
          else if(real!=0&&img==0)
            cout<<real<<endl;
            else if(  img <0 )
          cout<<real<<""<<img<<"i";



    }
    cmplx  sum(cmplx c)
    {
        cmplx result;
        result.real=real+c.real;
        result.img=img+c.img;
        return result;
    }

};
int cmplx::numC=0;
int cmplx::destC=0;
cmplx sub(cmplx A ,cmplx B)
{
    cmplx result;
        result.setReal(A.getReal()-B.getReal());
        result.setImg(A.getImg()-B.getImg());
        return result;
}
cmplx multi(cmplx A ,cmplx B , cmplx C)
{
    cmplx result;
        result.setReal(A.getReal()*B.getReal()*C.getReal());
        result.setImg(A.getImg()*B.getImg()*C.getImg());
        return result;
}
cmplx div(cmplx A ,cmplx B , cmplx C)
{
    cmplx result;

        result.setReal(A.getReal()/B.getReal()/C.getReal());
        result.setImg(A.getImg()/B.getImg()/C.getImg());

        return result;
}
       cmplx operator +(int r ,cmplx c)
    {
        cmplx result(c.getReal()+r,c.getImg());
        return result;
    }
       cmplx operator -(int r ,cmplx c)
    {
        cmplx result(r-c.getReal(),c.getImg());
        return result;
    }
int main()
{
   cmplx c1,c2,c3;
   int x,y;
   cout<<"enter first number "<<endl;
   cout<<"real = ";
   cin>>x;
   c1.setReal(x);
    cout<<"img = ";
   cin>>y;

   c1.setImg(y);
    cout<<"\nenter second number "<<endl;
   cout<<"real = ";
   cin>>x;
   c2.setReal(x);
    cout<<"img = ";
   cin>>y;
   cout<<endl;
   c2.setImg(y);
   cout<<"first num is "<<endl;
   c1.print();
   cout<<endl;
     cout<<"sum is 7 +c1"<<endl;
   c3=7+c1;
   c3.print();
   cout<<endl;
    cout<<"sum is c1 +c2"<<endl;
   c3=c1+c2;
   c3.print();
   cout<<endl;
    cout<<"sum is c1 +7"<<endl;
   c3=c1+7;
   c3.print();
   cout<<endl;
    cout<<"sum is 7-c1"<<endl;
   c3=7-c1;
   c3.print();
   cout<<endl;
   /*cout<<endl;
     cout<<"sub is "<<endl;
   c3=sub(c1,c2);
   c3.print();*/
   cout<<"cost = "<<cmplx::getNumC()<<"dest = "<< cmplx::getDestC()<<endl;



    return 0;
}
