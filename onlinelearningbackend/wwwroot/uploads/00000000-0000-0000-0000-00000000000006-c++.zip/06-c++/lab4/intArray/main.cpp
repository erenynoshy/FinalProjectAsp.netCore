#include <iostream>

using namespace std;
class intArray
{
    int *arr,arrSize;
   public:
       intArray(int siz)
       {

           arrSize=siz;
           arr=new int[arrSize];
       }
       ~intArray()
       {
           delete []arr;

       }
       intArray(const intArray & a)
       {
        arrSize=a.arrSize;
        arr=new int[arrSize];
        for(int i=0;i<arrSize;i++)
            arr[i]=a.arr[i];

       }
       int & operator[](int index)
       {
           if(index>=0&&index<arrSize)
            return arr[index];
       }
       int operator ==( intArray & right )
    {

       if(arrSize==right.arrSize){
        for(int i=0;i<arrSize;i++)
        if(arr[i]!=right.arr[i])
           return 0;
       return 1;
       }
       else
        return 0;
    }
         intArray & operator =(const intArray & a )
    {
        delete []arr;
        arrSize=a.arrSize;
         arr=new int(arrSize);
        for(int i=0;i<arrSize;i++)
            arr[i]=a.arr[i];
            return *this;

    }


};
int main()
{
 intArray a(5),b(4);
a[0]=4;
a[1]=4;
a[2]=4;
cout<<(b==a)<<endl;
b=a;
cout<<b[0]<<"\n"<<(b==a);


    return 0;
}
