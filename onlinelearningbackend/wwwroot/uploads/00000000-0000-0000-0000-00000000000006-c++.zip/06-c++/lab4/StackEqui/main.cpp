#include <iostream>

using namespace std;
class Stack
{
    int * stk;
    int tos,stkSize;
public:
    Stack (int l)
    {
        stkSize=l;
        tos=0;
        stk=new int[stkSize];
    }
    ~Stack ()
    {
        delete[] stk;
        cout<<"dest";
    }
     int operator ==(const Stack & right )
    {

       if(stkSize==right.stkSize){
        if(tos==right.tos){
        for(int i=0;i<tos;i++)
       {
           if( stk[i]!=right.stk[i])
            return 0;

       }
       return 1;
        }else return 0;
       }
       else return 0;


    }
    int isFull()
    {
        return(tos==stkSize);
    }

        int isEmpty()
    {
        return(tos==0);
    }
    int pop()
    {
        if(!isEmpty())
            return stk[--tos];
        else
            cout<<"empty"<<endl;

    }
    void push(int n)
    {

    if(!isFull())
     stk[tos++]=n;
    else
        cout<<"stack is full"<<endl;
    }
    int peak()
    {
         if(!isEmpty())
            return stk[tos-1];
    }
     Stack operator +(const Stack & right )
    {
        Stack result(stkSize+right.stkSize);
        result.tos=tos+right.tos;
        for(int i=0;i<result.tos;i++)
        {
            if(i<tos)
            result.push(stk[i]);
            else
            result.push(right.stk[i-tos]);

        }

        return result;
    }
};

int main()
{
    Stack s1(4),s2(4), s3(5);
    s1.push(5);
    s1.push(7);
    s2.push(5);
    s2.push(7);
    cout<<(s1==s2)<<endl;
    s3=s1+s2;
    cout<<s3.pop()<<endl;
    cout<<s3.pop()<<endl;
     cout<<s3.pop()<<endl;
    cout<<s3.pop();


    return 0;
}
