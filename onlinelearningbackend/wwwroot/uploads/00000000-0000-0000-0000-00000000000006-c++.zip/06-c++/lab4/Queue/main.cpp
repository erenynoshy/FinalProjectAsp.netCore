#include <iostream>

using namespace std;
class Queue
{
    int * que;
    int head , tail,sizeQ , countQ;
public:
    Queue (int n)
    {
        sizeQ=n;
        head=tail=0;
        que=new int[sizeQ];
        countQ=0;
    }
    Queue(const Queue & olds)
    {
        sizeQ=olds.sizeQ;

        que=new int[sizeQ];
        head=olds.head;
        tail=olds.tail;
        for(int i=0; i<sizeQ; i++)
            que[i]=olds.que[i];

    }
    int operator==(Queue &Right)
    {
        if(sizeQ==Right.sizeQ)
        {
            if(countQ==Right.countQ)
            {
                int i=head;
                int j=Right.head;
                for(int k=0; k<countQ; k++)
                {
                    if(head<tail && Right.head<Right.tail)

                        if(head>tail && Right.head<Right.tail )
                            if (i==sizeQ )
                                i=0;
                    if(head<tail && Right.head>Right.tail )
                        if (j==Right.sizeQ )
                            j=0;
                    if(head>=tail && Right.head>=Right.tail )
                    {
                        if(i==sizeQ)
                            i=0;
                        if(j==Right.sizeQ)
                            j=0;
                    }
                    if (que[i]!=Right.que[j])
                        return 0;
                    else
                    {
                        j++;
                        i++;
                    }

                }
                return 1;
            }
            else
                return 0;
        }
        else return 0;
    }

    Queue & operator =(Queue & right )
    {
        delete []que;
        sizeQ=right.sizeQ;
        que=new int[sizeQ];
        head=right.head;
        tail=right.tail;
        countQ=right.countQ;

        for(int i =0; i<sizeQ; i++)
        {

            que[i]=right.que[i];
        }

        return *this;
    }
    Queue  operator +( const Queue & right )
    {
        Queue result(sizeQ+right.sizeQ);
//        result.head=0;
        int i=head;

        for(int k=0; k<countQ; k++)
        {
            if(head>=tail )
            {
                if(i==sizeQ)
                    i=0;

            }
            result.enQ(que[i]);
            i++;
        }
        i=right.head;
        for(int k=countQ;k<(right.countQ+countQ); k++)
        {

            if(right.head>=right.tail )
            {
                if(i==right.sizeQ)
                    i=0;

            }
            result.enQ(right.que[i]);
            i++;
        }

        return result;
    }
    int isFull()
    {
        return(countQ==sizeQ);
    }
    int isEmpty()
    {
        return(countQ==0);
    }
    void enQ(int x)
    {
        if(!isFull())
        {

            que[tail++]=x;
            if(tail==sizeQ)
                tail=0;
            countQ++;
        }
        else
            cout<<"is full"<<endl;
    }
    int deQ()
    {
        if(!isEmpty())
        {
            int x;
            x=  que[head++];
            if(head==sizeQ)
                head=0;

            countQ--;
            return x;
        }

        cout<<"is empty"<<endl;
        return -1;
    }
    int peak()
    {
        if(!isEmpty())
            return que[head];
        else
            cout<<"is empty"<<endl;
    }

};
int main()
{
    Queue q(4),q2(5);
    q.enQ(5);
    q.enQ(6);
    q.enQ(7);
    q2.enQ(8);
    q2.enQ(8);

    //cout<<( q2==q)<<endl;
    //q2=q;
    // cout<<( q2==q)<<endl;
     Queue q1(q2+q);
    cout<<q1.deQ()<<endl;

    //cout<<q.peak()<<endl;
    //cout<<q.deQ()<<endl;


    return 0;
}
