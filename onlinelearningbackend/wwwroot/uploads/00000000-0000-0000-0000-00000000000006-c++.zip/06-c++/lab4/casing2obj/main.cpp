#include <iostream>
#include <string.h>
using namespace std;
class Employee;
class Person
{
    public:
    string fname,lname;
    double netSalary;
    Person(string _fname,string _lname,double _netSalary )
    {

         fname=_fname;
        lname=_lname;
        netSalary=_netSalary;
    }
    Person ()
    {
        fname="";
        lname="";
        netSalary=0;
    }
    operator Employee ();

};

class Employee
{
    public:
    string fullName;
    double baseSalary,Bouns;
    Employee(string _fullName,double _baseSalary ,double _Bouns)
    {
        fullName=_fullName;
        baseSalary=_baseSalary;
        Bouns=_Bouns;
    }
    Employee(){
             fullName="";
             baseSalary=0;
             Bouns=0;
    }
    operator Person ();
};
Person::operator Employee ()
{

   return Employee ((fname+" "+lname),netSalary-5,5);
}
Employee::operator Person ()
{

   return Person (fullName.substr(0,fullName.find(" ")),fullName.substr(fullName.find(" ")),baseSalary+Bouns);
}
int main()
{

   Person p("esraa","sliem",200.00),A;

   Employee e("esraa sliem",200,50),B;


     cout<< ((Employee)p).fullName<<endl;
     cout<< ((Person)e).fname<<endl;
     cout<< ((Person)e).lname;
}
