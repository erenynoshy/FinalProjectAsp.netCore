#include <iostream>

using namespace std;
class Parent
{
    int x,y;
public:
    Parent()
    {
        x=y=0;
    }
    Parent(int _x,int _y)
    {
        x=_x;
        y=_y;
    }
      ~Parent()
    {
        cout<<"dest"<<endl;
    }
    int sum()
    {
        return x+y;
    }
    int getX(){return x;}
    int getY(){return y;}
    void setX(int _x){x=_x;}
    void setY(int _y){y=_y;}


};
class Child:public Parent
{
   int z;
   public:
    int getZ(){return z;}
    void setZ(int _z){z=_z;}
    Child()
    {
        z=0;
    }
     Child(int _z,int _x,int _y):Parent(_x,_y)
    {
        z=_z;

    }
     ~Child()
    {
        cout<<"dest"<<endl;
    }
     int sum()
    {
        return z+Parent::sum();
    }


};
int main()
{
    Parent p(1,2);
    p.setX(3);
    p.setY(4);
    cout<<p.sum()<<endl;
    Child c(5,6,7);
    c.setX(8);
    c.setY(9);
    c.setZ(10);
    cout<<"sum = "<<c.sum()<<endl;

    return 0;
}
