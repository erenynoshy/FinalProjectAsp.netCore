#include <iostream>
#include "graphics.h"
using namespace std;
class Point
{
    int x,y;
    public:

    Point()
    {
     x=y=0;
    }
      Point(int a, int b)
    {
     x=a;
     y=b;
    }
    int getX(){return x;}
    int getY(){return y;}
    void setX(int a){x=a;}
    void setY(int a){y=a;}

};
class Rect
{

    Point UL,LR ;
public:
    Rect():UL(),LR(){

    }
    Rect(int x1 ,int y1 ,int x2,int y2):UL(x1,y1),LR(x2,y2)
    {

    }
    void draw ()
    {
        setcolor(4);
        rectangle(UL.getX(),UL.getY(),LR.getX(),LR.getY());
    }

};
class circ
{
    int radius;
    Point p;
public:
    circ ():p()
    {
        radius=0;
    }
       circ (int x1,int y1 ,int rad):p(x1,y1)
    {
        radius=rad;
    }
     void draw ()
    {
        setcolor(4);
        circle(p.getX(),p.getY(),radius);
    }

};
class Line{
    Point UL,LR ;
public:
    Line():UL(),LR(){

    }
    Line(int x1 ,int y1 ,int x2,int y2):UL(x1,y1),LR(x2,y2)
    {

    }
    void draw ()
    {
        setcolor(4);
        line(UL.getX(),UL.getY(),LR.getX(),LR.getY());
    }

};
class Pic
{
    public:
    Rect * pRec;
    int RNum;
     circ * pCirc;
    int CNum;
      Line * pLine;
    int LNum;
    Pic(  Rect * _pRec,int _RNum , circ * _pCirc,int _CNum,  Line * _pLine,int _LNum)
    {
        pRec=_pRec;
        RNum=_RNum;

        pCirc=_pCirc;
        CNum=_CNum;

        pLine=_pLine;
        LNum=_LNum;
    }
    void paint()
    {
        for(int i=0;i<RNum;i++)
            pRec[i].draw();
        for(int i=0;i<CNum;i++)
            pCirc[i].draw();
        for(int i=0;i<LNum;i++)
            pLine[i].draw();


    }
};
int main()
{
    initgraph();
    circ *c;
    c=new circ[2];
    c[0]=circ(100,200,50);
    c[1]=circ(100,300,100);

   Rect *r=new Rect(30,380,180,450);


    Line *l;
    l=new Line[7];
    l[0]=Line(80,210,55,280);
    l[1]=Line(120,210,145,280);
    l[2]=Line(70,380,70,340);
    l[3]=Line(130,380,130,340);
    l[4]=Line(160,390,150,420);
    l[5]=Line(150,420,170,420);
    l[6]=Line(170,420,160,390);
  Pic pp(r,1,c,2,l,7);
  pp.paint();



    return 0;
}
