#include <iostream>

using namespace std;
class GeoShape
{
protected:
    int dim1,dim2;
public:
    GeoShape(int d1, int d2)
    {
        dim1=d1;
        dim2=d2;
    }
      ~GeoShape()
    {
        cout<<"dest"<<endl;
    }
    void setDim1(int d1){dim1=d1;}
    void setDim2(int d2){dim2=d2;}
    int setDim1(){return dim1;}
    int setDim2(){return dim2;}
};
class Rect:public GeoShape
{
public:
    Rect(int w, int h):GeoShape(w,h){}
    ~Rect(){cout<<"dest"<<endl;}
    float cArea(){
        return dim1*dim2;
    }
};
class Square:protected Rect
{
public:
    Square(int l):Rect(l,l){}
    ~Square(){cout<<"dest"<<endl;}
    float cArea(){
        return dim1*dim2;
    }
};
class Tri:public GeoShape
{
public:
    Tri(int w, int h):GeoShape(w,h){}
    ~Tri(){cout<<"dest"<<endl;}
    float cArea(){
        return dim1*.5*dim2;
    }
};
class Circle:public GeoShape
{
public:
    Circle(int r):GeoShape(r,r){}
    ~Circle(){cout<<"dest"<<endl;}
    float cArea(){
        return dim1*dim2*3.14;
    }
    void setDim1(int d){dim1=dim2=d;}
    void setDim2(int d){dim1=dim2=d;}
};
int main()
{
    Rect r(4,5);
    Square s(4);
    Tri t(6,4);
    Circle c(10);
    cout<<"rect = "<<r.cArea()<<" square"<<s.cArea()<<"tri = "<<t.cArea()<<"circle = "<<c.cArea()<<endl;
    return 0;
}
