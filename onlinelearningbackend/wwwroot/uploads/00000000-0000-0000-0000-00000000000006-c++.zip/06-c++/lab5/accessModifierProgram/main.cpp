#include <iostream>

using namespace std;
class Base
{
private:
    int x;
protected:
    int y;
public:
    int z;
    int sum()
    {
        return x+y+z;
    }
};
class Child: protected Base
{
private:
    int A;
protected:
    int B;
public:
    int C;
    int sum()
    {
        return x+y+z+A+B+C;
    }
};
class Child2:protected Base
{
private:
    int k;
protected:
    int m;
public:
    int n;
    int sum()
    {
        return x+y+z+A+B+C+k+m+n;
    }
};

int main()
{
 Base o1;


}
